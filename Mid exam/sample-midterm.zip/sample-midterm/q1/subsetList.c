// subsetList.c 
// Written by Ashesh Mahidadia, Jan 2018

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include "DLList.h"


/* 
    You will submit only this one file.

    Implement the function "subsetList" below. Read the exam paper for 
    detailed specification and description of your task.  

    - DO NOT modify code in the file DLList.h . 
    - You can add helper functions in this file.  
    - DO NOT add "main" function in this file. 
    
*/


int subsetList(DLList L1, DLList L2){

	/* 
	   Your solution here 

	*/

	return 0;
}



